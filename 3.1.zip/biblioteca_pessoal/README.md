# Biblioteca Pessoal

Site local para organizar documentos em quatro categorias: **Saúde, Finanças, Judicial e Lazer**.

## Como abrir no VS Code

1. Extraia a pasta `biblioteca_pessoal.zip`.
2. Abra a pasta `biblioteca_pessoal` no Visual Studio Code.
3. Instale a extensão **Live Server** (Ritwick Dey), caso ainda não tenha.
4. Clique com o botão direito em `index.html` e selecione **Open with Live Server**.
5. Use o botão **Adicionar documento**, escolha uma categoria e selecione o arquivo.

Também é possível abrir o `index.html` diretamente em navegadores modernos, mas o Live Server é recomendado.

## Recursos

- Interface responsiva para computador e celular.
- Categorias clicáveis e contagem de documentos.
- Upload de arquivos com nome, descrição e etiquetas.
- Categoria Faculdade com classificação de trabalhos acadêmicos, provas, estudos, resumos, atividades e materiais de aula.
- Pesquisa por nome, descrição, arquivo ou etiqueta.
- Filtros por PDF, imagem e outros arquivos.
- Ordenação por data ou nome.
- Abrir/baixar e excluir documentos.
- Tema claro/escuro.
- Armazenamento no navegador usando IndexedDB; o arquivo não é enviado para um servidor.

## Estrutura

```text
biblioteca_pessoal/
├── index.html
├── README.md
├── css/
│   └── style.css
└── js/
    └── app.js
```

## Importante sobre seus arquivos

Os documentos ficam armazenados **no navegador e no dispositivo em que foram adicionados**. Limpar os dados do navegador, usar outro perfil ou trocar de computador pode apagar ou tornar os arquivos inacessíveis. Mantenha cópias de segurança dos documentos importantes. Esta versão não tem login, criptografia própria nem sincronização na nuvem; evite usar computador compartilhado para arquivos sensíveis.

Para disponibilizar o site na internet com conta pessoal, acesso em vários dispositivos e backup automático, será necessário integrar um backend e autenticação.


## Recursos adicionados
- Área **Formulários** para registrar trabalhos, provas, estudos, disciplina, professor, prazos, situação e anotações; os registros ficam no armazenamento local do navegador.
- Pesquisa acadêmica integrada por link ao Google Acadêmico: a consulta abre em uma nova aba.


## E-mail pelo Gmail
A seção **E-mail** permite preencher destinatário, cópia, assunto e mensagem. Ao clicar em **Abrir no Gmail**, o navegador abre uma nova aba do Gmail com os campos preenchidos para você revisar e enviar. O envio não é automático; é necessário confirmar no Gmail. Anexos devem ser adicionados na janela do Gmail.


## Pesquisa acadêmica na própria página
A pesquisa consulta a API pública OpenAlex para exibir publicações acadêmicas, autores, ano, fonte e resumo quando disponível diretamente no site. O serviço não é o Google Acadêmico em si; quando a API estiver indisponível, há um link de alternativa para abrir a consulta no Google Acadêmico. A disponibilidade depende de conexão com a internet e do serviço externo.
