const DB_NAME = "bibliotecaPessoalDB";
const DB_VERSION = 1;
const STORE = "documentos";
const CATEGORIES = {
  saude: { label: "Saúde", icon: "♡" },
  financas: { label: "Finanças", icon: "＄" },
  judicial: { label: "Judicial", icon: "⚖" },
  lazer: { label: "Lazer", icon: "✦" },
  faculdade: { label: "Faculdade", icon: "▣" }
};

let db;
let documents = [];
let activeCategory = "todos";
let activeFilter = "todos";
let toastTimer;

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(STORE)) {
        const store = database.createObjectStore(STORE, { keyPath: "id", autoIncrement: true });
        store.createIndex("category", "category", { unique: false });
        store.createIndex("createdAt", "createdAt", { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function storeRequest(mode, action) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE, mode);
    const request = action(transaction.objectStore(STORE));
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function loadDocuments() {
  documents = await storeRequest("readonly", store => store.getAll());
  render();
}

function formatDate(dateString) {
  return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short", year: "numeric" })
    .format(new Date(dateString));
}

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function getFileType(doc) {
  const type = (doc.fileType || "").toLowerCase();
  const name = doc.fileName.toLowerCase();
  if (type.includes("pdf") || name.endsWith(".pdf")) return "pdf";
  if (type.startsWith("image/") || /\.(png|jpe?g|gif|webp|bmp|svg)$/.test(name)) return "imagem";
  return "outros";
}

function filteredDocuments() {
  const query = $("#searchInput").value.trim().toLocaleLowerCase("pt-BR");
  let result = documents.filter(doc => {
    const categoryMatches = activeCategory === "todos" || doc.category === activeCategory;
    const text = `${doc.name} ${doc.description || ""} ${(doc.tags || []).join(" ")} ${doc.fileName} ${doc.academicType || ""}`.toLocaleLowerCase("pt-BR");
    const queryMatches = !query || text.includes(query);
    const type = getFileType(doc);
    const filterMatches = activeFilter === "todos" || type === activeFilter;
    return categoryMatches && queryMatches && filterMatches;
  });
  const sort = $("#sortSelect").value;
  result.sort((a, b) => {
    if (sort === "name") return a.name.localeCompare(b.name, "pt-BR");
    return sort === "oldest" ? new Date(a.createdAt) - new Date(b.createdAt) : new Date(b.createdAt) - new Date(a.createdAt);
  });
  return result;
}

function render() {
  const counts = Object.fromEntries(Object.keys(CATEGORIES).map(key => [key, documents.filter(doc => doc.category === key).length]));
  $("#totalDocs").textContent = documents.length;
  $("#usedCategories").innerHTML = `${Object.values(counts).filter(count => count > 0).length}<span class="stat-small"> / 5</span>`;
  const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  $("#recentDocs").textContent = documents.filter(doc => new Date(doc.createdAt).getTime() >= weekAgo).length;
  $("#count-todos").textContent = documents.length;
  Object.entries(counts).forEach(([key, count]) => {
    $(`#count-${key}`).textContent = count;
    $(`#card-${key}`).textContent = count;
  });

  const names = { todos: "Visão geral", ...Object.fromEntries(Object.entries(CATEGORIES).map(([key, value]) => [key, value.label])) };
  $("#breadcrumbCurrent").textContent = names[activeCategory];
  $("#pageTitle").innerHTML = activeCategory === "todos" ? 'Sua biblioteca, <span>em ordem.</span>' : `${names[activeCategory]}, <span>em ordem.</span>`;
  $("#documentsTitle").textContent = activeCategory === "todos" ? "Seus documentos" : `Documentos de ${names[activeCategory]}`;
  $("#documentsSubtitle").textContent = activeCategory === "todos" ? "Tudo o que você guardou, em um só lugar." : `Arquivos organizados na categoria ${names[activeCategory]}.`;

  $$(".nav-item").forEach(button => button.classList.toggle("active", button.dataset.category === activeCategory));
  const list = $("#documentsList");
  const results = filteredDocuments();
  list.innerHTML = "";
  results.forEach(doc => list.appendChild(createDocumentRow(doc)));
  $("#emptyState").style.display = results.length ? "none" : "block";
  list.style.display = results.length ? "grid" : "none";
  $("#emptyState h3").textContent = documents.length ? "Nenhum resultado encontrado" : "Nenhum documento por aqui";
  $("#emptyState p").textContent = documents.length ? "Tente outro termo ou remova alguns filtros." : "Adicione seu primeiro arquivo para começar a organizar sua biblioteca.";
}

function createDocumentRow(doc) {
  const row = document.createElement("article");
  row.className = "document-row";
  const type = getFileType(doc);
  const ext = (doc.fileName.split(".").pop() || "FILE").slice(0, 4).toUpperCase();
  const icon = document.createElement("div");
  icon.className = `file-icon ${type === "imagem" ? "image" : type}`;
  icon.textContent = type === "imagem" ? "▧" : ext;
  const info = document.createElement("div");
  info.className = "doc-info";
  const name = document.createElement("div");
  name.className = "doc-name";
  name.textContent = doc.name;
  name.title = doc.name;
  const description = document.createElement("div");
  description.className = "doc-description";
  description.textContent = doc.description || doc.fileName;
  const meta = document.createElement("div");
  meta.className = "doc-meta";
  const pill = document.createElement("span");
  pill.className = `category-pill ${doc.category}`;
  pill.textContent = CATEGORIES[doc.category]?.label || doc.category;
  meta.append(pill);
  if (doc.category === "faculdade" && doc.academicType) {
    const academicLabels = { trabalho: "Trabalho acadêmico", prova: "Prova", estudo: "Estudo", resumo: "Resumo", atividade: "Atividade", aula: "Material de aula", outro: "Outro" };
    const academic = document.createElement("span");
    academic.className = "category-pill faculdade-pill";
    academic.textContent = academicLabels[doc.academicType] || doc.academicType;
    meta.append(academic);
  }
  const date = document.createElement("span");
  date.className = "doc-date";
  date.textContent = formatDate(doc.createdAt);
  meta.append(date);
  const size = document.createElement("span");
  size.className = "doc-size";
  size.textContent = formatSize(doc.fileSize || 0);
  meta.append(size);
  (doc.tags || []).slice(0, 3).forEach(tag => {
    const tagEl = document.createElement("span");
    tagEl.className = "doc-tags";
    tagEl.textContent = `#${tag}`;
    meta.append(tagEl);
  });
  info.append(name, description, meta);

  const actions = document.createElement("div");
  actions.className = "doc-actions";
  const view = document.createElement("button");
  view.className = "small-action";
  view.title = "Visualizar documento";
  view.setAttribute("aria-label", `Visualizar ${doc.name}`);
  view.textContent = "◉";
  view.addEventListener("click", () => previewDocument(doc));
  const download = document.createElement("button");
  download.className = "small-action";
  download.title = "Baixar arquivo";
  download.setAttribute("aria-label", `Baixar ${doc.name}`);
  download.textContent = "↓";
  download.addEventListener("click", () => downloadDocument(doc));
  const remove = document.createElement("button");
  remove.className = "small-action delete";
  remove.title = "Excluir documento";
  remove.setAttribute("aria-label", `Excluir ${doc.name}`);
  remove.textContent = "×";
  remove.addEventListener("click", () => deleteDocument(doc));
  actions.append(view, download, remove);
  row.append(icon, info, actions);
  return row;
}

let currentPreviewUrl = null;
let currentPreviewDoc = null;

function previewDocument(doc) {
  const dialog = $("#viewerDialog");
  const body = $("#viewerBody");
  if (currentPreviewUrl) URL.revokeObjectURL(currentPreviewUrl);
  currentPreviewUrl = URL.createObjectURL(doc.fileBlob);
  currentPreviewDoc = doc;
  $("#viewerTitle").textContent = doc.name;
  body.replaceChildren();
  const type = getFileType(doc);
  if (type === "imagem") {
    const image = document.createElement("img");
    image.src = currentPreviewUrl;
    image.alt = doc.name;
    body.appendChild(image);
  } else if (type === "pdf") {
    const frame = document.createElement("iframe");
    frame.src = currentPreviewUrl;
    frame.title = `Visualização de ${doc.name}`;
    body.appendChild(frame);
  } else if ((doc.fileType || "").startsWith("text/") || /\.(txt|csv|json|md)$/i.test(doc.fileName)) {
    const message = document.createElement("div");
    message.className = "preview-message";
    message.textContent = "Preparando visualização do texto...";
    body.appendChild(message);
    doc.fileBlob.text().then(content => {
      if (currentPreviewDoc !== doc) return;
      const pre = document.createElement("pre");
      pre.style.cssText = "white-space:pre-wrap;overflow-wrap:anywhere;text-align:left;padding:20px;width:100%;margin:0;font:12px/1.6 monospace;color:var(--text)";
      pre.textContent = content;
      body.replaceChildren(pre);
    }).catch(() => { message.textContent = "Não foi possível visualizar este arquivo. Use Baixar arquivo para abri-lo em outro aplicativo."; });
  } else {
    const message = document.createElement("div");
    message.className = "preview-message";
    message.textContent = "A visualização direta não é compatível com este formato. Você pode baixar o arquivo e abri-lo no aplicativo adequado.";
    body.appendChild(message);
  }
  dialog.showModal();
}

function closeViewer() {
  $("#viewerDialog").close();
  $("#viewerBody").replaceChildren();
  if (currentPreviewUrl) URL.revokeObjectURL(currentPreviewUrl);
  currentPreviewUrl = null;
  currentPreviewDoc = null;
}

function downloadDocument(doc) {
  const url = URL.createObjectURL(doc.fileBlob);
  const link = document.createElement("a");
  link.href = url;
  link.download = doc.fileName;
  link.target = "_blank";
  link.rel = "noopener";
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

async function deleteDocument(doc) {
  if (!confirm(`Deseja excluir "${doc.name}" da sua biblioteca? Esta ação não pode ser desfeita.`)) return;
  await storeRequest("readwrite", store => store.delete(doc.id));
  await loadDocuments();
  showToast("Documento excluído.");
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

function openDialog(category = activeCategory === "todos" ? "saude" : activeCategory) {
  $("#documentForm").reset();
  $("#docCategory").value = category;
  updateAcademicField();
  $("#documentDialog").showModal();
}

function updateAcademicField() {
  const isFaculty = $("#docCategory").value === "faculdade";
  $("#academicTypeField").hidden = !isFaculty;
  $("#docAcademicType").required = isFaculty;
}
function closeDialog() { $("#documentDialog").close(); }

$("#docCategory").addEventListener("change", updateAcademicField);

$("#documentForm").addEventListener("submit", async event => {
  event.preventDefault();
  const file = $("#docFile").files[0];
  if (!file) { showToast("Escolha um arquivo antes de salvar."); return; }
  if (file.size > 100 * 1024 * 1024) {
    showToast("O arquivo excede o limite sugerido de 100 MB.");
    return;
  }
  const doc = {
    name: $("#docName").value.trim(),
    category: $("#docCategory").value,
    academicType: $("#docCategory").value === "faculdade" ? $("#docAcademicType").value : "",
    description: $("#docDescription").value.trim(),
    tags: $("#docTags").value.split(",").map(tag => tag.trim()).filter(Boolean),
    fileName: file.name,
    fileType: file.type || "",
    fileSize: file.size,
    fileBlob: file,
    createdAt: new Date().toISOString()
  };
  try {
    await storeRequest("readwrite", store => store.add(doc));
    closeDialog();
    activeCategory = doc.category;
    activeFilter = "todos";
    $$(".filter-chip").forEach(button => button.classList.toggle("selected", button.dataset.filter === "todos"));
    await loadDocuments();
    showToast("Documento salvo na sua biblioteca!");
  } catch (error) {
    console.error(error);
    showToast("Não foi possível salvar. Verifique o espaço disponível no navegador.");
  }
});

$$("[data-category]").forEach(button => button.addEventListener("click", () => {
  activeCategory = button.dataset.category;
  render();
  if (window.innerWidth <= 720) $("#sidebar").classList.remove("open");
  document.querySelector(".documents-section").scrollIntoView({ behavior: "smooth", block: "start" });
}));
$$(".filter-chip").forEach(button => button.addEventListener("click", () => {
  activeFilter = button.dataset.filter;
  $$(".filter-chip").forEach(chip => chip.classList.toggle("selected", chip === button));
  render();
}));
$("#searchInput").addEventListener("input", render);
$("#sortSelect").addEventListener("change", render);
["#addDocumentTop", "#addDocumentInline", "#emptyAdd"].forEach(selector => $(selector).addEventListener("click", () => openDialog()));
$("#closeViewer").addEventListener("click", closeViewer);
$("#closeViewerBottom").addEventListener("click", closeViewer);
$("#downloadFromViewer").addEventListener("click", () => { if (currentPreviewDoc) downloadDocument(currentPreviewDoc); });
$("#viewerDialog").addEventListener("click", event => {
  if (event.target === $("#viewerDialog")) closeViewer();
});
$("#closeDialog").addEventListener("click", closeDialog);
$("#cancelDialog").addEventListener("click", closeDialog);
$("#documentDialog").addEventListener("click", event => {
  if (event.target === $("#documentDialog")) closeDialog();
});
$("#themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const dark = document.body.classList.contains("dark");
  $("#themeToggle").textContent = dark ? "☾" : "☼";
  try { localStorage.setItem("bibliotecaTema", dark ? "dark" : "light"); } catch (_) {}
});
$("#mobileMenu").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
document.addEventListener("keydown", event => {
  if (event.key === "Escape") $("#sidebar").classList.remove("open");
});

(async function init() {
  try {
    db = await openDatabase();
    const savedTheme = localStorage.getItem("bibliotecaTema");
    if (savedTheme === "dark") {
      document.body.classList.add("dark");
      $("#themeToggle").textContent = "☾";
    }
    await loadDocuments();
  } catch (error) {
    console.error(error);
    $("#emptyState").style.display = "block";
    $("#emptyState h3").textContent = "Seu navegador não liberou o armazenamento";
    $("#emptyState p").textContent = "Abra o projeto pelo Live Server do VS Code e tente novamente.";
    showToast("Não foi possível iniciar o banco local.");
  }
})();

// Pesquisa acadêmica incorporada na própria página.
// Tentamos usar o endpoint público do Google Scholar via proxy CORS. Caso indisponível,
// mostramos uma alternativa embutida com resultados de OpenAlex (API pública acadêmica).
const scholarResults = $("#scholarResults");
function renderScholarMessage(title, message) {
  scholarResults.innerHTML = "";
  const wrap = document.createElement("div");
  wrap.className = "scholar-placeholder";
  const strong = document.createElement("strong"); strong.textContent = title;
  const p = document.createElement("p"); p.textContent = message;
  wrap.append(strong, p); scholarResults.append(wrap);
}
function safeExternalLink(url, text) {
  const a = document.createElement("a");
  a.href = url; a.target = "_blank"; a.rel = "noopener noreferrer"; a.textContent = text;
  return a;
}
function renderAcademicResults(results, query, sourceLabel) {
  scholarResults.innerHTML = "";
  const head = document.createElement("div"); head.className = "scholar-results-head";
  const title = document.createElement("h3"); title.textContent = `Resultados para “${query}”`;
  const source = document.createElement("span"); source.className = "scholar-source"; source.textContent = sourceLabel;
  head.append(title, source); scholarResults.append(head);
  if (!results.length) {
    renderScholarMessage("Nenhum resultado encontrado", "Tente outros termos ou uma expressão mais curta.");
    return;
  }
  results.forEach(item => {
    const article = document.createElement("article"); article.className = "scholar-result";
    const titleLink = safeExternalLink(item.url, item.title || "Publicação sem título");
    titleLink.className = "scholar-result-title";
    const meta = document.createElement("div"); meta.className = "scholar-result-meta";
    meta.textContent = [item.authors, item.year, item.venue].filter(Boolean).join(" · ");
    const description = document.createElement("p"); description.className = "scholar-result-description";
    description.textContent = item.description || "Resumo não disponível na fonte consultada.";
    const sourceLink = safeExternalLink(item.url, "Abrir publicação ↗"); sourceLink.className = "scholar-result-link";
    article.append(titleLink, meta, description, sourceLink); scholarResults.append(article);
  });
}
async function searchAcademic(query) {
  scholarResults.innerHTML = "";
  const loading = document.createElement("div"); loading.className = "scholar-placeholder";
  loading.innerHTML = "<span>⌕</span><strong>Pesquisando publicações…</strong><p>Aguarde enquanto consultamos o catálogo acadêmico.</p>";
  scholarResults.append(loading);
  // OpenAlex é uma API pública de metadados acadêmicos; seus resultados aparecem dentro do site.
  const url = "https://api.openalex.org/works?search=" + encodeURIComponent(query) + "&per-page=8&sort=relevance_score:desc";
  try {
    const response = await fetch(url, {headers: {"Accept":"application/json"}});
    if (!response.ok) throw new Error("Falha na consulta");
    const data = await response.json();
    const results = (data.results || []).map(work => {
      const authors = (work.authorships || []).slice(0, 3).map(a => a.author?.display_name).filter(Boolean).join(", ");
      const venue = work.primary_location?.source?.display_name || "";
      const abstractInverted = work.abstract_inverted_index;
      let description = "";
      if (abstractInverted) {
        const words = [];
        for (const [word, positions] of Object.entries(abstractInverted)) positions.forEach(pos => words[pos] = word);
        description = words.filter(Boolean).join(" ").slice(0, 450);
        if (description.length === 450) description += "…";
      }
      return {title: work.display_name, url: work.doi ? (work.doi.startsWith("http") ? work.doi : "https://doi.org/" + work.doi) : (work.primary_location?.landing_page_url || work.id), authors, year: work.publication_year || "", venue, description};
    }).filter(item => item.title && item.url);
    renderAcademicResults(results, query, "Resultados acadêmicos · OpenAlex");
  } catch (error) {
    renderScholarMessage("Não foi possível carregar os resultados", "A consulta em tempo real falhou. Verifique sua conexão e tente novamente. Você também pode abrir a pesquisa diretamente no Google Acadêmico usando o link abaixo.");
    const link = safeExternalLink("https://scholar.google.com/scholar?q=" + encodeURIComponent(query), "Abrir esta pesquisa no Google Acadêmico ↗");
    link.className = "scholar-result-link";
    scholarResults.querySelector(".scholar-placeholder")?.append(link);
  }
}
$("#scholarSearchForm").addEventListener("submit", event => {
  event.preventDefault();
  const query = $("#scholarQuery").value.trim();
  if (query) searchAcademic(query);
});

// Registros de formulários acadêmicos armazenados localmente.
const ACADEMIC_RECORDS_KEY = "bibliotecaPessoalRegistrosAcademicos";
function getAcademicRecords() {
  try { return JSON.parse(localStorage.getItem(ACADEMIC_RECORDS_KEY) || "[]"); } catch (_) { return []; }
}
function saveAcademicRecords(records) { localStorage.setItem(ACADEMIC_RECORDS_KEY, JSON.stringify(records)); }
function renderAcademicRecords() {
  const records = getAcademicRecords();
  const container = $("#academicRecords");
  if (!container) return;
  container.innerHTML = "";
  $("#recordCount").textContent = `${records.length} ${records.length === 1 ? "registro salvo" : "registros salvos"}`;
  $("#noAcademicRecords").style.display = records.length ? "none" : "grid";
  records.sort((a,b) => b.createdAt.localeCompare(a.createdAt)).forEach(record => {
    const article = document.createElement("article"); article.className = "academic-record";
    const top = document.createElement("div"); top.className = "academic-record-top";
    const title = document.createElement("div"); title.className = "academic-record-title"; title.textContent = record.title;
    const status = document.createElement("span"); status.className = "record-status" + (record.status === "Concluído" ? " done" : record.status === "Em andamento" ? " progress" : ""); status.textContent = record.status;
    top.append(title,status);
    const meta = document.createElement("div"); meta.className = "academic-record-meta";
    const bits = [record.type,record.course,record.subject ? `Disciplina: ${record.subject}` : "",record.professor ? `Professor(a): ${record.professor}` : "",record.deadline ? `Prazo: ${new Intl.DateTimeFormat("pt-BR",{dateStyle:"medium"}).format(new Date(record.deadline+"T12:00:00"))}` : ""].filter(Boolean);
    meta.textContent = bits.join(" • "); article.append(top,meta);
    if(record.notes){const notes=document.createElement("div");notes.className="academic-record-notes";notes.textContent=record.notes;article.append(notes);}
    const remove=document.createElement("button");remove.className="record-delete";remove.type="button";remove.textContent="Excluir registro";
    remove.addEventListener("click",()=>{if(confirm(`Excluir o registro "${record.title}"?`)){saveAcademicRecords(getAcademicRecords().filter(item=>item.id!==record.id));renderAcademicRecords();showToast("Registro acadêmico excluído.");}});
    article.append(remove);container.append(article);
  });
}
$("#academicForm").addEventListener("submit",event=>{
  event.preventDefault();const data=new FormData(event.currentTarget);
  const record={id:`${Date.now()}-${Math.random().toString(36).slice(2,8)}`,title:String(data.get("title")||"").trim(),type:String(data.get("type")||""),status:String(data.get("status")||"Pendente"),course:String(data.get("course")||"").trim(),subject:String(data.get("subject")||"").trim(),professor:String(data.get("professor")||"").trim(),deadline:String(data.get("deadline")||""),notes:String(data.get("notes")||"").trim(),createdAt:new Date().toISOString()};
  try{const records=getAcademicRecords();records.push(record);saveAcademicRecords(records);event.currentTarget.reset();renderAcademicRecords();showToast("Registro acadêmico salvo!");}catch(error){showToast("Não foi possível salvar o registro neste navegador.");}
});
const formsNav=document.querySelector('[data-view="formularios"]');
if(formsNav)formsNav.addEventListener("click",()=>{
  const section=$("#formsSection");const opening=section.hidden;section.hidden=!opening;formsNav.classList.toggle("active",opening);
  $$(".nav-item[data-category]").forEach(item=>item.classList.remove("active"));
  $("#breadcrumbCurrent").textContent=opening?"Formulários":"Visão geral";
  if(opening){renderAcademicRecords();section.scrollIntoView({behavior:"smooth",block:"start"});if(window.innerWidth<=720)$("#sidebar").classList.remove("open");}
  else{activeCategory="todos";render();}
});
document.addEventListener("DOMContentLoaded",renderAcademicRecords);

// E-mail: prepara uma mensagem no Gmail para revisão e envio manual.
$("#emailForm").addEventListener("submit", event => {
  event.preventDefault();
  const to = $("#emailTo").value.trim();
  const cc = $("#emailCc").value.trim();
  const subject = $("#emailSubject").value.trim();
  const body = $("#emailBody").value;
  if (!to || !subject || !body.trim()) {
    showToast("Preencha destinatário, assunto e mensagem.");
    return;
  }
  const params = new URLSearchParams();
  params.set("view", "cm");
  params.set("fs", "1");
  params.set("to", to);
  if (cc) params.set("cc", cc);
  params.set("su", subject);
  params.set("body", body);
  const gmailUrl = "https://mail.google.com/mail/?" + params.toString();
  const opened = window.open(gmailUrl, "_blank", "noopener,noreferrer");
  if (!opened) {
    showToast("O navegador bloqueou a nova aba. Permita pop-ups ou abra o Gmail e tente novamente.");
  } else {
    showToast("Mensagem preparada no Gmail. Revise e clique em Enviar.");
  }
});

// Navegação da seção de e-mail
const emailNav = document.querySelector('[data-view="email"]');
if (emailNav) emailNav.addEventListener("click", () => {
  const section = $("#emailSection");
  const opening = section.hidden;
  section.hidden = !opening;
  emailNav.classList.toggle("active", opening);
  $$(".nav-item[data-category]").forEach(item => item.classList.remove("active"));
  const formsSection = $("#formsSection");
  if (formsSection) formsSection.hidden = true;
  const formsNav = document.querySelector('[data-view="formularios"]');
  if (formsNav) formsNav.classList.remove("active");
  $("#breadcrumbCurrent").textContent = opening ? "E-mail" : "Visão geral";
  if (opening) {
    section.scrollIntoView({behavior:"smooth", block:"start"});
    if (window.innerWidth <= 720) $("#sidebar").classList.remove("open");
  } else {
    activeCategory = "todos";
    render();
  }
});
