# Biblioteca Pessoal

Site local para organizar documentos em quatro categorias: **Saúde, Finanças, Judicial e Lazer**.

## Como abrir no VS Code

1. Extraia a pasta `biblioteca_pessoal.zip`.
2. Abra a pasta `biblioteca_pessoal` no Visual Studio Code.
3. Instale a extensão **Live Server** (Ritwick Dey), caso ainda não tenha.
4. Clique com o botão direito em `index.html` e selecione **Open with Live Server**.
5. Use o botão **Adicionar documento**, escolha uma categoria e selecione o arquivo.

Também é possível abrir o `index.html` diretamente em navegadores modernos, mas o Live Server é recomendado.

## Recursos

- Interface responsiva para computador e celular.
- Categorias clicáveis e contagem de documentos.
- Upload de arquivos com nome, descrição e etiquetas.
- Categoria Faculdade com classificação de trabalhos acadêmicos, provas, estudos, resumos, atividades e materiais de aula.
- Pesquisa por nome, descrição, arquivo ou etiqueta.
- Filtros por PDF, imagem e outros arquivos.
- Ordenação por data ou nome.
- Abrir/baixar e excluir documentos.
- Tema claro/escuro.
- Armazenamento no navegador usando IndexedDB; o arquivo não é enviado para um servidor.

## Estrutura

```text
biblioteca_pessoal/
├── index.html
├── README.md
├── css/
│   └── style.css
└── js/
    └── app.js
```

## Importante sobre seus arquivos

Os documentos ficam armazenados **no navegador e no dispositivo em que foram adicionados**. Limpar os dados do navegador, usar outro perfil ou trocar de computador pode apagar ou tornar os arquivos inacessíveis. Mantenha cópias de segurança dos documentos importantes. Esta versão não tem login, criptografia própria nem sincronização na nuvem; evite usar computador compartilhado para arquivos sensíveis.

Para disponibilizar o site na internet com conta pessoal, acesso em vários dispositivos e backup automático, será necessário integrar um backend e autenticação.
