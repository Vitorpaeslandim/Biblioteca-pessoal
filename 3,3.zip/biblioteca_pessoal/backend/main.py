from contextlib import asynccontextmanager
from datetime import datetime, date
from pathlib import Path
import json
import os
import shutil
import sqlite3
import uuid

from fastapi import FastAPI, File, Form, HTTPException, UploadFile, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
DB_PATH = DATA_DIR / "biblioteca.db"
DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with connect() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS academic_records (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            type TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Pendente',
            course TEXT NOT NULL DEFAULT '',
            subject TEXT NOT NULL DEFAULT '',
            professor TEXT NOT NULL DEFAULT '',
            deadline TEXT NOT NULL DEFAULT '',
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS documents (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            academic_type TEXT NOT NULL DEFAULT '',
            description TEXT NOT NULL DEFAULT '',
            tags_json TEXT NOT NULL DEFAULT '[]',
            file_name TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            file_type TEXT NOT NULL DEFAULT 'application/octet-stream',
            file_size INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
        );
        """)

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(
    title="API da Biblioteca Pessoal",
    description="API local para registros acadêmicos e documentos, com banco SQLite.",
    version="1.0.0",
    lifespan=lifespan,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Para uso local; restrinja antes de publicar na internet.
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

class AcademicRecordIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    type: str = Field(min_length=1, max_length=80)
    status: str = Field(default="Pendente", max_length=40)
    course: str = Field(default="", max_length=160)
    subject: str = Field(default="", max_length=160)
    professor: str = Field(default="", max_length=160)
    deadline: str = Field(default="", max_length=20)
    notes: str = Field(default="", max_length=5000)

def academic_dict(row):
    return {
        "id": row["id"], "title": row["title"], "type": row["type"],
        "status": row["status"], "course": row["course"], "subject": row["subject"],
        "professor": row["professor"], "deadline": row["deadline"], "notes": row["notes"],
        "createdAt": row["created_at"],
    }

def document_dict(row):
    return {
        "id": row["id"], "name": row["name"], "category": row["category"],
        "academicType": row["academic_type"], "description": row["description"],
        "tags": json.loads(row["tags_json"]), "fileName": row["file_name"],
        "fileType": row["file_type"], "fileSize": row["file_size"],
        "createdAt": row["created_at"],
        "downloadUrl": f"/api/documents/{row['id']}/file",
    }

@app.get("/api/health")
def health():
    return {"status": "ok", "database": "SQLite", "database_file": str(DB_PATH.name)}

@app.get("/api/academic-records")
def list_academic_records():
    with connect() as conn:
        rows = conn.execute("SELECT * FROM academic_records ORDER BY created_at DESC").fetchall()
    return [academic_dict(row) for row in rows]

@app.post("/api/academic-records", status_code=201)
def create_academic_record(payload: AcademicRecordIn):
    record_id = str(uuid.uuid4())
    created_at = datetime.now().astimezone().isoformat()
    values = payload.model_dump()
    with connect() as conn:
        conn.execute("""INSERT INTO academic_records
        (id,title,type,status,course,subject,professor,deadline,notes,created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (record_id, values["title"].strip(), values["type"], values["status"], values["course"],
         values["subject"], values["professor"], values["deadline"], values["notes"], created_at))
        row = conn.execute("SELECT * FROM academic_records WHERE id=?", (record_id,)).fetchone()
    return academic_dict(row)

@app.delete("/api/academic-records/{record_id}", status_code=204)
def delete_academic_record(record_id: str):
    with connect() as conn:
        cursor = conn.execute("DELETE FROM academic_records WHERE id=?", (record_id,))
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Registro acadêmico não encontrado.")
    return None

@app.get("/api/documents")
def list_documents():
    with connect() as conn:
        rows = conn.execute("SELECT * FROM documents ORDER BY created_at DESC").fetchall()
    return [document_dict(row) for row in rows]

@app.post("/api/documents", status_code=201)
async def upload_document(
    name: str = Form(..., min_length=1, max_length=100),
    category: str = Form(...),
    academic_type: str = Form(""),
    description: str = Form(""),
    tags: str = Form(""),
    file: UploadFile = File(...),
):
    allowed_categories = {"saude", "financas", "judicial", "lazer", "faculdade"}
    if category not in allowed_categories:
        raise HTTPException(status_code=422, detail="Categoria inválida.")
    original_name = Path(file.filename or "arquivo").name
    document_id = str(uuid.uuid4())
    suffix = Path(original_name).suffix[:20]
    stored_name = f"{document_id}{suffix}"
    destination = UPLOAD_DIR / stored_name
    size = 0
    try:
        with destination.open("wb") as output:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > 100 * 1024 * 1024:
                    output.close()
                    destination.unlink(missing_ok=True)
                    raise HTTPException(status_code=413, detail="O arquivo excede o limite de 100 MB.")
                output.write(chunk)
    finally:
        await file.close()
    created_at = datetime.now().astimezone().isoformat()
    tags_list = [tag.strip() for tag in tags.split(",") if tag.strip()][:30]
    with connect() as conn:
        conn.execute("""INSERT INTO documents
        (id,name,category,academic_type,description,tags_json,file_name,stored_name,file_type,file_size,created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (document_id, name.strip(), category, academic_type, description, json.dumps(tags_list),
         original_name, stored_name, file.content_type or "application/octet-stream", size, created_at))
        row = conn.execute("SELECT * FROM documents WHERE id=?", (document_id,)).fetchone()
    return document_dict(row)

@app.get("/api/documents/{document_id}/file")
def download_document(document_id: str, preview: bool = Query(default=False)):
    with connect() as conn:
        row = conn.execute("SELECT * FROM documents WHERE id=?", (document_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Documento não encontrado.")
    path = UPLOAD_DIR / row["stored_name"]
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Arquivo não encontrado no armazenamento.")
    return FileResponse(path, media_type=row["file_type"], filename=row["file_name"], content_disposition_type="inline" if preview else "attachment")

@app.delete("/api/documents/{document_id}", status_code=204)
def delete_document(document_id: str):
    with connect() as conn:
        row = conn.execute("SELECT stored_name FROM documents WHERE id=?", (document_id,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Documento não encontrado.")
        conn.execute("DELETE FROM documents WHERE id=?", (document_id,))
    (UPLOAD_DIR / row["stored_name"]).unlink(missing_ok=True)
    return None
