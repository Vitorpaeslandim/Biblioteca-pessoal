# Biblioteca Pessoal — versão com API e banco de dados

Esta versão integra o site a uma API própria em **FastAPI** e um banco de dados **SQLite**. Os arquivos enviados pelo formulário e os registros acadêmicos são guardados no backend, não apenas no armazenamento do navegador.

## O que está integrado

- Upload, listagem, visualização, download e exclusão de documentos via API.
- Registros acadêmicos: criar, listar e excluir via API.
- SQLite criado automaticamente em `backend/data/biblioteca.db`.
- Arquivos enviados guardados em `backend/data/uploads/`.
- Documentação interativa da API em `http://127.0.0.1:8000/docs`.
- Pesquisa acadêmica externa continua usando OpenAlex/Crossref; Gmail continua abrindo uma mensagem para revisão e envio manual.

## Como iniciar no Windows / VS Code

**1. Inicie a API**
- Abra a pasta `backend` no VS Code.
- Dê duplo clique em `iniciar_api.bat` ou execute no terminal:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m uvicorn main:app --reload
```

Na primeira execução, a API instala as dependências e cria o banco SQLite. Deixe esse terminal aberto.

**2. Inicie o site**
- Na pasta principal do projeto, clique com o botão direito em `index.html`.
- Selecione **Open with Live Server**.
- O site chama a API em `http://127.0.0.1:8000/api`.

**3. Teste a API**
- Abra `http://127.0.0.1:8000/docs`.
- Teste `GET /api/health`, `GET /api/documents` e `GET /api/academic-records`.

## Estrutura

```text
biblioteca_pessoal/
├── index.html
├── css/style.css
├── js/app.js
├── README.md
└── backend/
    ├── main.py
    ├── requirements.txt
    ├── iniciar_api.bat
    └── data/                 # criado automaticamente
        ├── biblioteca.db
        └── uploads/
```

## Endpoints principais

| Método | Rota | Função |
|---|---|---|
| GET | `/api/health` | Verificar se a API está ativa |
| GET | `/api/documents` | Listar documentos |
| POST | `/api/documents` | Enviar documento com metadados e arquivo |
| GET | `/api/documents/{id}/file` | Baixar arquivo |
| GET | `/api/documents/{id}/file?preview=true` | Abrir arquivo para visualização |
| DELETE | `/api/documents/{id}` | Excluir documento |
| GET | `/api/academic-records` | Listar registros acadêmicos |
| POST | `/api/academic-records` | Criar registro acadêmico |
| DELETE | `/api/academic-records/{id}` | Excluir registro acadêmico |

## Limitações e segurança importantes

- **Esta é uma configuração para desenvolvimento local.** Não publique a API na internet do jeito que está: ainda não há login, autorização por usuário, criptografia de arquivos ou limitação de acesso por conta.
- CORS está permissivo para facilitar o teste local; restrinja as origens antes de publicar.
- O banco e os arquivos ficam no computador onde a API está executando. Faça cópias de segurança de `backend/data/`.
- A versão não migra automaticamente os documentos antigos do IndexedDB nem os registros acadêmicos antigos do `localStorage`. Esses itens antigos continuam no perfil/navegador em que foram salvos; exporte ou reenvie-os se quiser colocá-los no novo banco.
- O SQLite é uma boa opção para uso individual e protótipo. Para vários usuários e implantação online, recomendo autenticação e PostgreSQL.
- O Gmail não envia e-mails automaticamente; o usuário revisa e envia no Gmail.

## Requisitos

Python 3.10 ou mais recente. Recomenda-se Python 3.11+.
