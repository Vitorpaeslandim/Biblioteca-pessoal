# Biblioteca Pessoal — API, banco de dados e cadastro de usuários

Esta versão mantém as funções existentes e adiciona cadastro/login de usuários com dados separados por conta. A pesquisa acadêmica voltou ao comportamento simples: ao digitar um tema e clicar em **Pesquisar**, o navegador abre a página de resultados do Google Acadêmico.

## Funcionalidades

- Categorias Saúde, Finanças, Judicial, Lazer e Faculdade.
- Pesquisa acadêmica redirecionada ao Google Acadêmico.
- Formulários acadêmicos salvos no banco via API.
- Upload, listagem, visualização, download e exclusão de documentos pelo backend.
- E-mail preparado no Gmail para revisão e envio manual.
- Cadastro e login por nome, e-mail e senha.
- Senhas armazenadas com hash PBKDF2; token de sessão com validade de 24 horas.
- Documentos e registros acadêmicos filtrados pelo usuário autenticado.
- Banco SQLite criado automaticamente em `backend/data/biblioteca.db`.
- Documentação interativa em `http://127.0.0.1:8000/docs`.

## Versão local Biblioteca Pessoal 2.0\n\nNovos recursos: busca avançada por categoria/período, favoritos, agenda e lembretes internos, referências bibliográficas com formatação ABNT sugerida, backup JSON e restauração aditiva sem apagar dados. O banco cria as novas tabelas automaticamente e adiciona a coluna de favoritos sem excluir documentos existentes.\n\nPara iniciar no Windows, execute `backend\\iniciar_api.bat` e abra `index.html` com Live Server.\n\n## Publicação gratuita para testes\n\nConsulte o roteiro completo em `PUBLICAR_NO_RENDER.md`. O arquivo `render.yaml` configura a API e o site no Render. **A hospedagem gratuita pode perder banco e arquivos em reinicializações ou deploys; use somente dados de teste.**\n\n## Como executar no Windows / VS Code

1. Extraia o ZIP e abra a pasta `biblioteca_pessoal` no VS Code.
2. Abra a pasta `backend` e execute `iniciar_api.bat`. Na primeira execução, é necessária conexão com a internet para instalar as dependências. Deixe o terminal aberto.
3. Na pasta principal do projeto, clique com o botão direito em `index.html` e selecione **Open with Live Server**.
4. A tela de entrada será exibida. Selecione **Criar conta**, preencha nome, e-mail e uma senha de pelo menos 8 caracteres. Depois você poderá entrar com essa conta.
5. Para testar a API, acesse `http://127.0.0.1:8000/docs`.

Também é possível iniciar manualmente pelo terminal na pasta `backend`:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m uvicorn main:app --reload
```

## Rotas de autenticação

| Método | Rota | Função |
|---|---|---|
| POST | `/api/auth/register` | Criar conta |
| POST | `/api/auth/login` | Entrar |
| GET | `/api/auth/me` | Conferir sessão atual |

Outras rotas exigem token de autenticação. Use `Authorization: Bearer <token>`.

## Segurança e limitações

- **Esta versão é para desenvolvimento local. Não a publique diretamente na internet.** Antes de hospedar, configure HTTPS, CORS restrito, proteção contra tentativas repetidas de login, recuperação de senha e revisão de segurança.
- O token é guardado no `localStorage` do navegador, opção prática para protótipo local, mas menos indicada para uma aplicação pública de produção.
- O banco e os arquivos ficam no computador em que o backend está rodando. Faça backup da pasta `backend/data/`.
- A pesquisa acadêmica abre o Google Acadêmico em uma nova aba; se o navegador bloquear pop-ups, a navegação será feita na mesma aba.
- O Gmail apenas prepara a mensagem; o envio precisa ser confirmado manualmente.
- Os documentos e registros criados na versão anterior no IndexedDB/localStorage não são importados automaticamente.
- O SQLite atende bem a um protótipo individual/local. Para publicação multiusuário, use PostgreSQL e uma implantação protegida.

## Estrutura

```text
biblioteca_pessoal/
├── index.html
├── css/style.css
├── js/app.js
├── README.md
└── backend/
    ├── main.py
    ├── requirements.txt
    ├── iniciar_api.bat
    └── data/  (criada automaticamente; não compartilhar publicamente)
```
