// Esta versão foi preparada para execução local no Windows.
(() => {
  const localApi = "http://127.0.0.1:8000/api";
  window.BIBLIOTECA_API_BASE = localApi;
})();
