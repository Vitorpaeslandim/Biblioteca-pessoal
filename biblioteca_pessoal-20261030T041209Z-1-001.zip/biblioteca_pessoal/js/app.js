const API_BASE = window.BIBLIOTECA_API_BASE || "http://127.0.0.1:8000/api";
const AUTH_TOKEN_KEY = "bibliotecaApiToken";
const AUTH_USER_KEY = "bibliotecaApiUser";
let currentUser = null;
async function apiFetch(url, options = {}) {
  const token = localStorage.getItem(AUTH_TOKEN_KEY);
  const headers = new Headers(options.headers || {});
  if (token) headers.set("Authorization", `Bearer ${token}`);
  const response = await fetch(url, {...options, headers});
  if (response.status === 401 && token && !url.endsWith("/auth/me")) clearSession();
  return response;
}
const DB_NAME = "bibliotecaPessoalDB";
const DB_VERSION = 1;
const STORE = "documentos";
const CATEGORIES = {
  saude: { label: "Saúde", icon: "♡" },
  financas: { label: "Finanças", icon: "＄" },
  judicial: { label: "Judicial", icon: "⚖" },
  lazer: { label: "Lazer", icon: "✦" },
  faculdade: { label: "Faculdade", icon: "▣" }
};

let db;
let documents = [];
let activeCategory = "todos";
let activeFilter = "todos";
let toastTimer;

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(STORE)) {
        const store = database.createObjectStore(STORE, { keyPath: "id", autoIncrement: true });
        store.createIndex("category", "category", { unique: false });
        store.createIndex("createdAt", "createdAt", { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function storeRequest(mode, action) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE, mode);
    const request = action(transaction.objectStore(STORE));
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function loadDocuments() {
  const response = await apiFetch(`${API_BASE}/documents`);
  if (!response.ok) throw new Error("A API não conseguiu carregar os documentos.");
  documents = await response.json();
  render();
}

function formatDate(dateString) {
  return new Intl.DateTimeFormat("pt-BR", { day: "2-digit", month: "short", year: "numeric" })
    .format(new Date(dateString));
}

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function getFileType(doc) {
  const type = (doc.fileType || "").toLowerCase();
  const name = doc.fileName.toLowerCase();
  if (type.includes("pdf") || name.endsWith(".pdf")) return "pdf";
  if (type.startsWith("image/") || /\.(png|jpe?g|gif|webp|bmp|svg)$/.test(name)) return "imagem";
  return "outros";
}

function filteredDocuments() {
  const query = $("#searchInput").value.trim().toLocaleLowerCase("pt-BR");
  let result = documents.filter(doc => {
    const categoryFilter = $("#categorySearchFilter")?.value || "";
    const categoryMatches = (activeCategory === "todos" || activeCategory === "favoritos" || doc.category === activeCategory)
      && (!categoryFilter || doc.category === categoryFilter);
    const text = `${doc.name} ${doc.description || ""} ${(doc.tags || []).join(" ")} ${doc.fileName} ${doc.academicType || ""}`.toLocaleLowerCase("pt-BR");
    const queryMatches = !query || text.includes(query);
    const type = getFileType(doc);
    const filterMatches = activeFilter === "todos" || type === activeFilter;
    const days = Number($("#dateSearchFilter")?.value || "0");
    const dateMatches = !days || (Date.now() - new Date(doc.createdAt).getTime()) <= days * 86400000;
    const favoriteMatches = activeCategory !== "favoritos" || doc.isFavorite;
    return categoryMatches && queryMatches && filterMatches && dateMatches && favoriteMatches;
  });
  const sort = $("#sortSelect").value;
  result.sort((a, b) => {
    if (sort === "name") return a.name.localeCompare(b.name, "pt-BR");
    return sort === "oldest" ? new Date(a.createdAt) - new Date(b.createdAt) : new Date(b.createdAt) - new Date(a.createdAt);
  });
  return result;
}

function render() {
  const counts = Object.fromEntries(Object.keys(CATEGORIES).map(key => [key, documents.filter(doc => doc.category === key).length]));
  $("#totalDocs").textContent = documents.length;
  $("#usedCategories").innerHTML = `${Object.values(counts).filter(count => count > 0).length}<span class="stat-small"> / 5</span>`;
  const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  $("#recentDocs").textContent = documents.filter(doc => new Date(doc.createdAt).getTime() >= weekAgo).length;
  const favoriteCountEl = $("#dashboardFavoriteCount");
  if (favoriteCountEl) {
    const favCount = documents.filter(doc => doc.isFavorite).length;
    favoriteCountEl.textContent = `${favCount} ${favCount === 1 ? "documento salvo" : "documentos salvos"}`;
  }
  $("#count-todos").textContent = documents.length;
  Object.entries(counts).forEach(([key, count]) => {
    $(`#count-${key}`).textContent = count;
    $(`#card-${key}`).textContent = count;
  });

  const names = { todos: "Visão geral", ...Object.fromEntries(Object.entries(CATEGORIES).map(([key, value]) => [key, value.label])) };
  $("#breadcrumbCurrent").textContent = names[activeCategory];
  $("#pageTitle").innerHTML = activeCategory === "todos" ? 'Sua biblioteca, <span>em ordem.</span>' : `${names[activeCategory]}, <span>em ordem.</span>`;
  $("#documentsTitle").textContent = activeCategory === "todos" ? "Seus documentos" : `Documentos de ${names[activeCategory]}`;
  $("#documentsSubtitle").textContent = activeCategory === "todos" ? "Tudo o que você guardou, em um só lugar." : `Arquivos organizados na categoria ${names[activeCategory]}.`;

  $$(".nav-item").forEach(button => button.classList.toggle("active", button.dataset.category === activeCategory));
  const list = $("#documentsList");
  const results = filteredDocuments();
  list.innerHTML = "";
  results.forEach(doc => list.appendChild(createDocumentRow(doc)));
  $("#emptyState").style.display = results.length ? "none" : "block";
  list.style.display = results.length ? "grid" : "none";
  $("#emptyState h3").textContent = documents.length ? "Nenhum resultado encontrado" : "Nenhum documento por aqui";
  $("#emptyState p").textContent = documents.length ? "Tente outro termo ou remova alguns filtros." : "Adicione seu primeiro arquivo para começar a organizar sua biblioteca.";
  renderFavorites();
}
function renderFavorites() {
  const container = $("#favoritesList");
  if (!container) return;
  const favorites = documents.filter(doc => doc.isFavorite);
  container.replaceChildren(...favorites.map(createDocumentRow));
  $("#favoritesEmpty").hidden = favorites.length > 0;
  container.hidden = favorites.length === 0;
}

function createDocumentRow(doc) {
  const row = document.createElement("article");
  row.className = "document-row";
  const type = getFileType(doc);
  const ext = (doc.fileName.split(".").pop() || "FILE").slice(0, 4).toUpperCase();
  const icon = document.createElement("div");
  icon.className = `file-icon ${type === "imagem" ? "image" : type}`;
  icon.textContent = type === "imagem" ? "▧" : ext;
  const info = document.createElement("div");
  info.className = "doc-info";
  const name = document.createElement("div");
  name.className = "doc-name";
  name.textContent = doc.name;
  name.title = doc.name;
  const description = document.createElement("div");
  description.className = "doc-description";
  description.textContent = doc.description || doc.fileName;
  const meta = document.createElement("div");
  meta.className = "doc-meta";
  const pill = document.createElement("span");
  pill.className = `category-pill ${doc.category}`;
  pill.textContent = CATEGORIES[doc.category]?.label || doc.category;
  meta.append(pill);
  if (doc.category === "faculdade" && doc.academicType) {
    const academicLabels = { trabalho: "Trabalho acadêmico", prova: "Prova", estudo: "Estudo", resumo: "Resumo", atividade: "Atividade", aula: "Material de aula", outro: "Outro" };
    const academic = document.createElement("span");
    academic.className = "category-pill faculdade-pill";
    academic.textContent = academicLabels[doc.academicType] || doc.academicType;
    meta.append(academic);
  }
  const date = document.createElement("span");
  date.className = "doc-date";
  date.textContent = formatDate(doc.createdAt);
  meta.append(date);
  const size = document.createElement("span");
  size.className = "doc-size";
  size.textContent = formatSize(doc.fileSize || 0);
  meta.append(size);
  (doc.tags || []).slice(0, 3).forEach(tag => {
    const tagEl = document.createElement("span");
    tagEl.className = "doc-tags";
    tagEl.textContent = `#${tag}`;
    meta.append(tagEl);
  });
  info.append(name, description, meta);

  const actions = document.createElement("div");
  actions.className = "doc-actions";
  const view = document.createElement("button");
  view.className = "small-action";
  view.title = "Visualizar documento";
  view.setAttribute("aria-label", `Visualizar ${doc.name}`);
  view.textContent = "◉";
  view.addEventListener("click", () => previewDocument(doc));
  const download = document.createElement("button");
  download.className = "small-action";
  download.title = "Baixar arquivo";
  download.setAttribute("aria-label", `Baixar ${doc.name}`);
  download.textContent = "↓";
  download.addEventListener("click", () => downloadDocument(doc));
  const favorite = document.createElement("button");
  favorite.className = "small-action favorite-action";
  favorite.title = doc.isFavorite ? "Remover dos favoritos" : "Adicionar aos favoritos";
  favorite.setAttribute("aria-label", favorite.title);
  favorite.textContent = doc.isFavorite ? "★" : "☆";
  favorite.classList.toggle("is-favorite", !!doc.isFavorite);
  favorite.addEventListener("click", async () => {
    try {
      const response = await apiFetch(`${API_BASE}/documents/${encodeURIComponent(doc.id)}/favorite`, {method:"PATCH"});
      if (!response.ok) throw new Error("Falha ao atualizar favorito");
      await loadDocuments();
      renderFavorites();
      showToast(doc.isFavorite ? "Removido dos favoritos." : "Adicionado aos favoritos.");
    } catch (_) { showToast("Não foi possível atualizar o favorito."); }
  });
  const remove = document.createElement("button");
  remove.className = "small-action delete";
  remove.title = "Excluir documento";
  remove.setAttribute("aria-label", `Excluir ${doc.name}`);
  remove.textContent = "×";
  remove.addEventListener("click", () => deleteDocument(doc));
  actions.append(view, download, favorite, remove);
  row.append(icon, info, actions);
  return row;
}

let currentPreviewUrl = null;
let currentPreviewDoc = null;

function previewDocument(doc) {
  const dialog = $("#viewerDialog");
  const body = $("#viewerBody");
  if (currentPreviewUrl && currentPreviewUrl.startsWith("blob:")) URL.revokeObjectURL(currentPreviewUrl);
  currentPreviewUrl = `${API_BASE}/documents/${encodeURIComponent(doc.id)}/file?preview=true`;
  currentPreviewDoc = doc;
  $("#viewerTitle").textContent = doc.name;
  body.replaceChildren();
  const type = getFileType(doc);
  if (type === "imagem") {
    const image = document.createElement("img");
    image.src = currentPreviewUrl;
    image.alt = doc.name;
    body.appendChild(image);
  } else if (type === "pdf") {
    const frame = document.createElement("iframe");
    frame.src = currentPreviewUrl;
    frame.title = `Visualização de ${doc.name}`;
    body.appendChild(frame);
  } else {
    const frame = document.createElement("iframe");
    frame.src = currentPreviewUrl;
    frame.title = `Visualização de ${doc.name}`;
    frame.style.cssText = "width:100%;height:70vh;border:0";
    body.appendChild(frame);
  }
  dialog.showModal();
}

function closeViewer() {
  $("#viewerDialog").close();
  $("#viewerBody").replaceChildren();
  if (currentPreviewUrl && currentPreviewUrl.startsWith("blob:")) URL.revokeObjectURL(currentPreviewUrl);
  currentPreviewUrl = null;
  currentPreviewDoc = null;
}

function downloadDocument(doc) {
  const link = document.createElement("a");
  link.href = `${API_BASE}/documents/${encodeURIComponent(doc.id)}/file`;
  link.download = doc.fileName;
  link.target = "_blank";
  link.rel = "noopener";
  document.body.appendChild(link);
  link.click();
  link.remove();
}

async function deleteDocument(doc) {
  if (!confirm(`Deseja excluir "${doc.name}" da sua biblioteca? Esta ação não pode ser desfeita.`)) return;
  try {
    const response = await apiFetch(`${API_BASE}/documents/${encodeURIComponent(doc.id)}`, {method:"DELETE"});
    if (!response.ok) throw new Error("Falha ao excluir documento.");
    await loadDocuments();
    showToast("Documento excluído do banco de dados.");
  } catch (error) {
    console.error(error);
    showToast("Não foi possível excluir. Verifique se a API está ligada.");
  }
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

function openDialog(category = activeCategory === "todos" ? "saude" : activeCategory) {
  $("#documentForm").reset();
  $("#docCategory").value = category;
  updateAcademicField();
  $("#documentDialog").showModal();
}

function updateAcademicField() {
  const isFaculty = $("#docCategory").value === "faculdade";
  $("#academicTypeField").hidden = !isFaculty;
  $("#docAcademicType").required = isFaculty;
}
function closeDialog() { $("#documentDialog").close(); }

$("#docCategory").addEventListener("change", updateAcademicField);

$("#documentForm").addEventListener("submit", async event => {
  event.preventDefault();
  const file = $("#docFile").files[0];
  if (!file) { showToast("Escolha um arquivo antes de salvar."); return; }
  if (file.size > 100 * 1024 * 1024) { showToast("O arquivo excede o limite de 100 MB."); return; }
  const payload = new FormData();
  payload.append("name", $("#docName").value.trim());
  payload.append("category", $("#docCategory").value);
  payload.append("academic_type", $("#docCategory").value === "faculdade" ? $("#docAcademicType").value : "");
  payload.append("description", $("#docDescription").value.trim());
  payload.append("tags", $("#docTags").value);
  payload.append("file", file);
  try {
    const response = await apiFetch(`${API_BASE}/documents`, {method:"POST", body:payload});
    if (!response.ok) {
      const detail = await response.json().catch(() => ({}));
      throw new Error(detail.detail || "Falha ao salvar o documento.");
    }
    const doc = await response.json();
    closeDialog();
    activeCategory = doc.category;
    activeFilter = "todos";
    $$(".filter-chip").forEach(button => button.classList.toggle("selected", button.dataset.filter === "todos"));
    await loadDocuments();
    showToast("Documento salvo no banco de dados!");
  } catch (error) {
    console.error(error);
    showToast("Não foi possível salvar. Inicie a API e tente novamente.");
  }
});

$$("[data-category]").forEach(button => button.addEventListener("click", () => {
  activeCategory = button.dataset.category;
  render();
  if (window.innerWidth <= 720) $("#sidebar").classList.remove("open");
  document.querySelector(".documents-section").scrollIntoView({ behavior: "smooth", block: "start" });
}));
$$(".filter-chip").forEach(button => button.addEventListener("click", () => {
  activeFilter = button.dataset.filter;
  $$(".filter-chip").forEach(chip => chip.classList.toggle("selected", chip === button));
  render();
}));
$("#searchInput").addEventListener("input", render);
$("#sortSelect").addEventListener("change", render);
$("#categorySearchFilter").addEventListener("change", render);
$("#dateSearchFilter").addEventListener("change", render);
["#addDocumentTop", "#addDocumentInline", "#emptyAdd"].forEach(selector => $(selector).addEventListener("click", () => openDialog()));
$("#closeViewer").addEventListener("click", closeViewer);
$("#closeViewerBottom").addEventListener("click", closeViewer);
$("#downloadFromViewer").addEventListener("click", () => { if (currentPreviewDoc) downloadDocument(currentPreviewDoc); });
$("#viewerDialog").addEventListener("click", event => {
  if (event.target === $("#viewerDialog")) closeViewer();
});
$("#closeDialog").addEventListener("click", closeDialog);
$("#cancelDialog").addEventListener("click", closeDialog);
$("#documentDialog").addEventListener("click", event => {
  if (event.target === $("#documentDialog")) closeDialog();
});
$("#themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const dark = document.body.classList.contains("dark");
  $("#themeToggle").textContent = dark ? "☾" : "☼";
  try { localStorage.setItem("bibliotecaTema", dark ? "dark" : "light"); } catch (_) {}
});
$("#mobileMenu").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
document.addEventListener("keydown", event => {
  if (event.key === "Escape") $("#sidebar").classList.remove("open");
});

function showAuthMessage(message, isError = true) {
  const el = $("#authMessage");
  el.textContent = message;
  el.classList.toggle("error", isError);
}
function switchAuthMode(mode) {
  const registering = mode === "register";
  $("#loginForm").hidden = registering;
  $("#registerForm").hidden = !registering;
  $("#loginTab").classList.toggle("active", !registering);
  $("#registerTab").classList.toggle("active", registering);
  $("#authIntro").textContent = registering ? "Crie uma conta para organizar seus documentos e registros." : "Entre para acessar seus documentos e registros.";
  showAuthMessage("");
}
function setAuthenticated(session) {
  localStorage.setItem(AUTH_TOKEN_KEY, session.token);
  localStorage.setItem(AUTH_USER_KEY, JSON.stringify(session.user));
  currentUser = session.user;
  $("#authScreen").hidden = true;
  $(".app-shell").hidden = false;
  $("#userAvatar").textContent = (currentUser.name || "BP").trim().split(/\s+/).slice(0,2).map(part=>part[0]).join("").toUpperCase();
  $("#userAvatar").title = currentUser.name;
  const savedTheme = localStorage.getItem("bibliotecaTema");
  if (savedTheme === "dark") { document.body.classList.add("dark"); $("#themeToggle").textContent = "☾"; }
  loadDocuments().catch(error => { console.error(error); showToast("Não foi possível carregar os documentos. Confira a API."); });
  updateDashboardAgenda();
}
function clearSession() {
  localStorage.removeItem(AUTH_TOKEN_KEY);
  localStorage.removeItem(AUTH_USER_KEY);
  currentUser = null;
  $(".app-shell").hidden = true;
  $("#authScreen").hidden = false;
  $("#loginForm").reset();
  $("#registerForm").reset();
  switchAuthMode("login");
}
$("#loginTab").addEventListener("click",()=>switchAuthMode("login"));
$("#registerTab").addEventListener("click",()=>switchAuthMode("register"));
$("#loginForm").addEventListener("submit",async event=>{
  event.preventDefault(); showAuthMessage("Entrando…",false);
  try {
    const response=await fetch(`${API_BASE}/auth/login`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:$("#loginEmail").value.trim(),password:$("#loginPassword").value})});
    const data=await response.json();
    if(!response.ok) throw new Error(data.detail || "Não foi possível entrar.");
    setAuthenticated(data);
  } catch(error) { showAuthMessage(error.message || "Não foi possível conectar à API."); }
});
$("#registerForm").addEventListener("submit",async event=>{
  event.preventDefault(); showAuthMessage("Criando sua conta…",false);
  try {
    const response=await fetch(`${API_BASE}/auth/register`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:$("#registerName").value.trim(),email:$("#registerEmail").value.trim(),password:$("#registerPassword").value})});
    const data=await response.json();
    if(!response.ok) throw new Error(data.detail || "Não foi possível criar a conta.");
    setAuthenticated(data);
  } catch(error) { showAuthMessage(error.message || "Não foi possível conectar à API."); }
});
$("#logoutButton").addEventListener("click",clearSession);

(async function init() {
  try {
    const healthResponse = await fetch(`${API_BASE}/health`);
    if (!healthResponse.ok) throw new Error("API indisponível");
    const token = localStorage.getItem(AUTH_TOKEN_KEY);
    const savedUser = localStorage.getItem(AUTH_USER_KEY);
    if (token && savedUser) {
      const response = await apiFetch(`${API_BASE}/auth/me`);
      if (response.ok) setAuthenticated({token,user:await response.json()});
      else clearSession();
    } else {
      $("#authScreen").hidden = false;
      $(".app-shell").hidden = true;
    }
  } catch (error) {
    $("#authScreen").hidden = false;
    $(".app-shell").hidden = true;
    showAuthMessage("Não foi possível conectar à API. Inicie o backend e recarregue a página.");
  }
})();

// Pesquisa acadêmica: envia a consulta diretamente ao Google Acadêmico.
$("#scholarSearchForm").addEventListener("submit", event => {
  event.preventDefault();
  const query = $("#scholarQuery").value.trim();
  if (!query) return;
  const url = "https://scholar.google.com/scholar?q=" + encodeURIComponent(query);
  const newTab = window.open(url, "_blank", "noopener,noreferrer");
  if (!newTab) window.location.href = url;
});

// Registros acadêmicos persistidos pela API e banco SQLite.
let academicRecordsCache = [];
async function loadAcademicRecords() {
  const response = await apiFetch(`${API_BASE}/academic-records`);
  if (!response.ok) throw new Error("Falha ao carregar registros acadêmicos.");
  academicRecordsCache = await response.json();
  renderAcademicRecords(academicRecordsCache);
}
function renderAcademicRecords(records = academicRecordsCache) {
  const container = $("#academicRecords");
  if (!container) return;
  container.innerHTML = "";
  $("#recordCount").textContent = `${records.length} ${records.length === 1 ? "registro salvo" : "registros salvos"}`;
  $("#noAcademicRecords").style.display = records.length ? "none" : "grid";
  records.forEach(record => {
    const article = document.createElement("article"); article.className = "academic-record";
    const top = document.createElement("div"); top.className = "academic-record-top";
    const title = document.createElement("div"); title.className = "academic-record-title"; title.textContent = record.title;
    const status = document.createElement("span"); status.className = "record-status" + (record.status === "Concluído" ? " done" : record.status === "Em andamento" ? " progress" : ""); status.textContent = record.status;
    top.append(title,status);
    const meta = document.createElement("div"); meta.className = "academic-record-meta";
    const bits = [record.type,record.course,record.subject ? `Disciplina: ${record.subject}` : "",record.professor ? `Professor(a): ${record.professor}` : "",record.deadline ? `Prazo: ${new Intl.DateTimeFormat("pt-BR",{dateStyle:"medium"}).format(new Date(record.deadline+"T12:00:00"))}` : ""].filter(Boolean);
    meta.textContent = bits.join(" • "); article.append(top,meta);
    if(record.notes){const notes=document.createElement("div");notes.className="academic-record-notes";notes.textContent=record.notes;article.append(notes);}
    const remove=document.createElement("button");remove.className="record-delete";remove.type="button";remove.textContent="Excluir registro";
    remove.addEventListener("click",async()=>{
      if(!confirm(`Excluir o registro "${record.title}"?`)) return;
      try {
        const response=await apiFetch(`${API_BASE}/academic-records/${encodeURIComponent(record.id)}`,{method:"DELETE"});
        if(!response.ok) throw new Error("Falha ao excluir");
        await loadAcademicRecords(); showToast("Registro acadêmico excluído do banco de dados.");
      } catch(error) { showToast("Não foi possível excluir. Verifique se a API está ligada."); }
    });
    article.append(remove);container.append(article);
  });
}
$("#academicForm").addEventListener("submit",async event=>{
  event.preventDefault();const data=new FormData(event.currentTarget);
  const record={title:String(data.get("title")||"").trim(),type:String(data.get("type")||""),status:String(data.get("status")||"Pendente"),course:String(data.get("course")||"").trim(),subject:String(data.get("subject")||"").trim(),professor:String(data.get("professor")||"").trim(),deadline:String(data.get("deadline")||""),notes:String(data.get("notes")||"").trim()};
  try {
    const response=await apiFetch(`${API_BASE}/academic-records`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(record)});
    if(!response.ok) throw new Error("Falha ao salvar");
    event.currentTarget.reset(); await loadAcademicRecords(); showToast("Registro acadêmico salvo no banco de dados!");
  } catch(error) { console.error(error); showToast("Não foi possível salvar. Verifique se a API está ligada."); }
});
const formsNav=document.querySelector('[data-view="formularios"]');
if(formsNav)formsNav.addEventListener("click",async()=>{
  closeAllViews();
  const section=$("#formsSection");section.hidden=false;formsNav.classList.add("active");
  $("#breadcrumbCurrent").textContent="Formulários";
  try{await loadAcademicRecords();}catch(e){showToast("API indisponível para carregar os formulários.");}
  section.scrollIntoView({behavior:"smooth",block:"start"});if(window.innerWidth<=720)$("#sidebar").classList.remove("open");
});

// Navegação comum das novas áreas.
const viewSections = {
  agenda: "#agendaSection",
  referencias: "#referencesSection",
  backup: "#backupSection",
  favoritos: "#favoritesSection",
  email: "#emailSection",
  formularios: "#formsSection"
};
function closeAllViews() {
  Object.values(viewSections).forEach(selector => { const el = $(selector); if (el) el.hidden = true; });
  $$(".nav-item[data-view]").forEach(item => item.classList.remove("active"));
  $$(".nav-item[data-category]").forEach(item => item.classList.toggle("active", item.dataset.category === activeCategory));
}
async function openNewView(name, title) {
  closeAllViews();
  const section = $(viewSections[name]);
  if (!section) return;
  section.hidden = false;
  const nav = document.querySelector(`[data-view="${name}"]`);
  if (nav) nav.classList.add("active");
  $("#breadcrumbCurrent").textContent = title;
  if (name === "agenda") await loadAgenda();
  if (name === "referencias") await loadReferences();
  if (name === "backup") {}
  if (name === "favoritos") renderFavorites();
  section.scrollIntoView({behavior:"smooth", block:"start"});
  if (window.innerWidth <= 720) $("#sidebar").classList.remove("open");
}
["agenda","referencias","backup","favoritos"].forEach(name => {
  const nav = document.querySelector(`[data-view="${name}"]`);
  if (nav) nav.addEventListener("click", () => {
    const titles = {agenda:"Agenda e lembretes",referencias:"Referências ABNT",backup:"Backup e recuperação",favoritos:"Favoritos"};
    openNewView(name, titles[name]).catch(error => { console.error(error); showToast("Não foi possível carregar esta área."); });
  });
});

$("#dashboardFavorites").addEventListener("click", () => openNewView("favoritos","Favoritos"));
$("#dashboardAgenda").addEventListener("click", () => openNewView("agenda","Agenda e lembretes"));
$("#dashboardBackup").addEventListener("click", () => openNewView("backup","Backup e recuperação"));
async function updateDashboardAgenda() {
  const summary = $("#dashboardAgendaSummary");
  if (!summary) return;
  try {
    const response = await apiFetch(`${API_BASE}/agenda`);
    if (!response.ok) throw new Error("Agenda indisponível");
    const events = await response.json();
    const today = new Date().toISOString().slice(0,10);
    const pending = events.filter(item => !item.completed && item.eventDate >= today).sort((a,b) => (a.eventDate+a.eventTime).localeCompare(b.eventDate+b.eventTime));
    if (!pending.length) summary.textContent = "Nenhum compromisso futuro";
    else {
      const first = pending[0];
      const d = new Date(`${first.eventDate}T12:00:00`).toLocaleDateString("pt-BR",{day:"2-digit",month:"short"});
      summary.textContent = `${pending.length} pendente(s) • próximo: ${first.title} (${d})`;
    }
  } catch (_) { summary.textContent = "Abra a agenda para consultar"; }
}
$$("[data-category]").forEach(button => button.addEventListener("click", () => {
  closeAllViews();
  activeCategory = button.dataset.category;
  render();
}));

// Agenda com lembretes visíveis dentro do site.
let agendaCache = [];
async function loadAgenda() {
  const response = await apiFetch(`${API_BASE}/agenda`);
  if (!response.ok) throw new Error("Falha ao carregar agenda.");
  agendaCache = await response.json();
  renderAgenda();
}
function renderAgenda() {
  const container = $("#agendaList");
  if (!container) return;
  container.replaceChildren();
  const upcoming = agendaCache.filter(item => !item.completed).sort((a,b) => (a.eventDate+a.eventTime).localeCompare(b.eventDate+b.eventTime));
  $("#agendaEmpty").hidden = upcoming.length > 0;
  upcoming.forEach(item => {
    const card = document.createElement("article"); card.className = "academic-record";
    const title = document.createElement("div"); title.className = "academic-record-title"; title.textContent = item.title;
    const meta = document.createElement("div"); meta.className = "academic-record-meta";
    const date = new Date(`${item.eventDate}T${item.eventTime || "12:00"}:00`);
    meta.textContent = `${date.toLocaleString("pt-BR",{dateStyle:"medium",...(item.eventTime?{timeStyle:"short"}:{})})} • ${item.category} • prioridade ${item.priority}`;
    const notes = document.createElement("p"); notes.className = "academic-record-notes"; notes.textContent = item.notes || "";
    const actions = document.createElement("div"); actions.className = "inline-actions";
    const done = document.createElement("button"); done.className = "secondary-button"; done.type = "button"; done.textContent = "Concluir";
    done.addEventListener("click", async () => {
      const response = await apiFetch(`${API_BASE}/agenda/${item.id}`, {method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({...item,completed:true,event_date:item.eventDate,event_time:item.eventTime})});
      if (!response.ok) return showToast("Não foi possível concluir o compromisso.");
      await loadAgenda(); showToast("Compromisso concluído.");
    });
    const del = document.createElement("button"); del.className = "record-delete"; del.type = "button"; del.textContent = "Excluir";
    del.addEventListener("click", async () => {
      if (!confirm(`Excluir "${item.title}" da agenda?`)) return;
      const response = await apiFetch(`${API_BASE}/agenda/${item.id}`, {method:"DELETE"});
      if (response.ok) { await loadAgenda(); showToast("Compromisso excluído."); }
    });
    actions.append(done,del); card.append(title,meta); if(item.notes)card.append(notes); card.append(actions); container.append(card);
  });
  const today = new Date().toISOString().slice(0,10);
  const due = upcoming.filter(item => item.eventDate <= today);
  if (due.length && !sessionStorage.getItem("agendaAviso"+today)) {
    showToast(`Você tem ${due.length} compromisso(s) vencido(s) ou para hoje.`);
    sessionStorage.setItem("agendaAviso"+today,"1");
  }
}
$("#agendaForm").addEventListener("submit", async event => {
  event.preventDefault();
  const payload = {title:$("#eventTitle").value.trim(),event_date:$("#eventDate").value,event_time:$("#eventTime").value,category:$("#eventCategory").value,priority:$("#eventPriority").value,notes:$("#eventNotes").value.trim(),completed:false};
  try {
    const response = await apiFetch(`${API_BASE}/agenda`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
    if (!response.ok) { const data=await response.json(); throw new Error(data.detail || "Falha ao salvar."); }
    event.currentTarget.reset(); await loadAgenda(); showToast("Compromisso salvo.");
  } catch(error) { showToast(error.message || "Não foi possível salvar a agenda."); }
});

// Referências bibliográficas: a formatação é uma sugestão para revisão, não substitui a conferência da norma.
let referencesCache = [];
function formatABNT(ref) {
  const authors = ref.authors.trim() ? ref.authors.trim().toUpperCase() : "AUTOR NÃO INFORMADO";
  const title = ref.title.trim();
  const year = ref.year.trim() || "[s. d.]";
  if (ref.sourceType === "artigo") {
    let out = `${authors}. ${title}. ${ref.journal || "[Periódico não informado]"}, ${ref.city || "[S. l.]"},`;
    if (ref.volume) out += ` v. ${ref.volume}`;
    if (ref.issue) out += `, n. ${ref.issue}`;
    if (ref.pages) out += `, p. ${ref.pages}`;
    return `${out}, ${year}.` + (ref.doi ? ` DOI: ${ref.doi}.` : ref.url ? ` Disponível em: ${ref.url}. Acesso em: ${ref.accessDate || "[data de acesso]"}.` : "");
  }
  if (ref.sourceType === "site") return `${authors}. ${title}. ${year}.` + (ref.url ? ` Disponível em: ${ref.url}. Acesso em: ${ref.accessDate || "[data de acesso]"}.` : "");
  if (ref.sourceType === "tcc") return `${authors}. ${title}. ${year}. Trabalho acadêmico. ${ref.publisher || "[Instituição não informada]"}.` + (ref.city ? ` ${ref.city}.` : "");
  return `${authors}. ${title}. ${ref.city ? ref.city + ": " : ""}${ref.publisher || "[Editora não informada]"}, ${year}.`;
}
async function loadReferences() {
  const response = await apiFetch(`${API_BASE}/references`);
  if (!response.ok) throw new Error("Falha ao carregar referências.");
  referencesCache = await response.json(); renderReferences();
}
function renderReferences() {
  const container = $("#referencesList"); if (!container) return;
  container.replaceChildren();
  $("#referenceCount").textContent = `${referencesCache.length} fonte(s) salva(s)`;
  $("#referencesEmpty").hidden = referencesCache.length > 0;
  referencesCache.forEach(ref => {
    const card = document.createElement("article"); card.className = "academic-record";
    const title = document.createElement("div"); title.className = "academic-record-title"; title.textContent = ref.title;
    const citation = document.createElement("p"); citation.className = "academic-record-notes"; citation.textContent = formatABNT(ref);
    const copy = document.createElement("button"); copy.className = "secondary-button"; copy.type="button"; copy.textContent="Copiar referência";
    copy.addEventListener("click", async()=>{try{await navigator.clipboard.writeText(formatABNT(ref));showToast("Referência copiada.");}catch(_){showToast("Não foi possível copiar automaticamente.");}});
    const del = document.createElement("button"); del.className="record-delete"; del.type="button"; del.textContent="Excluir";
    del.addEventListener("click",async()=>{if(!confirm(`Excluir a referência "${ref.title}"?`))return;const r=await apiFetch(`${API_BASE}/references/${ref.id}`,{method:"DELETE"});if(r.ok){await loadReferences();showToast("Referência excluída.");}});
    card.append(title,citation,copy,del); container.append(card);
  });
}
$("#referenceForm").addEventListener("submit", async event => {
  event.preventDefault();
  const payload = {source_type:$("#refType").value,authors:$("#refAuthors").value.trim(),title:$("#refTitle").value.trim(),year:$("#refYear").value.trim(),city:$("#refCity").value.trim(),publisher:$("#refPublisher").value.trim(),journal:$("#refJournal").value.trim(),volume:$("#refVolume").value.trim(),pages:$("#refPages").value.trim(),doi:$("#refDoi").value.trim(),url:$("#refUrl").value.trim(),access_date:$("#refAccessDate").value,notes:$("#refNotes").value.trim()};
  try {
    const response=await apiFetch(`${API_BASE}/references`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
    if(!response.ok){const data=await response.json();throw new Error(data.detail||"Falha ao salvar referência.");}
    event.currentTarget.reset();await loadReferences();showToast("Referência salva.");
  } catch(error){showToast(error.message||"Não foi possível salvar a referência.");}
});

// Backup exporta os dados do usuário autenticado. A restauração só adiciona itens novos.
$("#exportBackup").addEventListener("click", async () => {
  try {
    showToast("Preparando backup…");
    const response=await apiFetch(`${API_BASE}/backup`);
    if(!response.ok){const data=await response.json();throw new Error(data.detail||"Falha ao gerar backup.");}
    const data=await response.blob();const url=URL.createObjectURL(data);
    const link=document.createElement("a");link.href=url;link.download=`biblioteca-pessoal-backup-${new Date().toISOString().slice(0,10)}.json`;
    document.body.append(link);link.click();link.remove();URL.revokeObjectURL(url);showToast("Backup baixado.");
  } catch(error){showToast(error.message||"Não foi possível gerar o backup.");}
});
$("#restoreBackup").addEventListener("click", async () => {
  const file=$("#backupFile").files[0]; if(!file)return showToast("Escolha um arquivo de backup primeiro.");
  if(file.size>60*1024*1024)return showToast("O arquivo de backup é maior que 60 MB.");
  if(!confirm("Importar este backup? Os dados atuais não serão apagados; itens novos serão adicionados."))return;
  try {
    const backup=JSON.parse(await file.text());
    const response=await apiFetch(`${API_BASE}/backup/restore`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({backup})});
    const data=await response.json();if(!response.ok)throw new Error(data.detail||"Falha ao restaurar backup.");
    await loadDocuments();await loadAcademicRecords();await loadAgenda();await loadReferences();
    showToast(`Backup restaurado: ${data.imported.documents} documentos, ${data.imported.agenda} compromissos.`);
  } catch(error){showToast(error.message||"Arquivo inválido ou não foi possível restaurar.");}
});


// E-mail: prepara uma mensagem no Gmail para revisão e envio manual.
$("#emailForm").addEventListener("submit", event => {
  event.preventDefault();
  const to = $("#emailTo").value.trim();
  const cc = $("#emailCc").value.trim();
  const subject = $("#emailSubject").value.trim();
  const body = $("#emailBody").value;
  if (!to || !subject || !body.trim()) {
    showToast("Preencha destinatário, assunto e mensagem.");
    return;
  }
  const params = new URLSearchParams();
  params.set("view", "cm");
  params.set("fs", "1");
  params.set("to", to);
  if (cc) params.set("cc", cc);
  params.set("su", subject);
  params.set("body", body);
  const gmailUrl = "https://mail.google.com/mail/?" + params.toString();
  const opened = window.open(gmailUrl, "_blank", "noopener,noreferrer");
  if (!opened) {
    showToast("O navegador bloqueou a nova aba. Permita pop-ups ou abra o Gmail e tente novamente.");
  } else {
    showToast("Mensagem preparada no Gmail. Revise e clique em Enviar.");
  }
});

// Navegação da seção de e-mail
const emailNav = document.querySelector('[data-view="email"]');
if (emailNav) emailNav.addEventListener("click", () => openNewView("email", "E-mail"));
