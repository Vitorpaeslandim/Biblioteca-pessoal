from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
import hashlib, hmac, json, os, secrets, sqlite3, uuid, base64

from fastapi import FastAPI, File, Form, HTTPException, UploadFile, Query, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field, EmailStr

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
DB_PATH = DATA_DIR / "biblioteca.db"
SECRET_PATH = DATA_DIR / ".secret_key"
DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
if not SECRET_PATH.exists():
    SECRET_PATH.write_text(secrets.token_hex(32), encoding="utf-8")
SECRET_KEY = SECRET_PATH.read_text(encoding="utf-8").strip().encode()
bearer = HTTPBearer(auto_error=False)

def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def init_db():
    with connect() as conn:
        # Preserve tables from the earlier single-user API before creating the multi-user schema.
        for table in ("academic_records", "documents"):
            exists = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
            if exists:
                columns = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
                if "user_id" not in columns:
                    legacy = table + "_legacy"
                    legacy_exists = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (legacy,)).fetchone()
                    if not legacy_exists:
                        conn.execute(f"ALTER TABLE {table} RENAME TO {legacy}")
                    else:
                        conn.execute(f"DROP TABLE {table}")
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS academic_records (
            id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            title TEXT NOT NULL, type TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Pendente',
            course TEXT NOT NULL DEFAULT '', subject TEXT NOT NULL DEFAULT '',
            professor TEXT NOT NULL DEFAULT '', deadline TEXT NOT NULL DEFAULT '',
            notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS documents (
            id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            name TEXT NOT NULL, category TEXT NOT NULL, academic_type TEXT NOT NULL DEFAULT '',
            description TEXT NOT NULL DEFAULT '', tags_json TEXT NOT NULL DEFAULT '[]',
            file_name TEXT NOT NULL, stored_name TEXT NOT NULL, file_type TEXT NOT NULL DEFAULT 'application/octet-stream',
            file_size INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
        );
        """)

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(title="API da Biblioteca Pessoal", description="API com cadastro de usuários, autenticação, documentos e registros acadêmicos.", version="2.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])

class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)

class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)

class AcademicRecordIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    type: str = Field(min_length=1, max_length=80)
    status: str = Field(default="Pendente", max_length=40)
    course: str = Field(default="", max_length=160)
    subject: str = Field(default="", max_length=160)
    professor: str = Field(default="", max_length=160)
    deadline: str = Field(default="", max_length=20)
    notes: str = Field(default="", max_length=5000)

def now_iso():
    return datetime.now(timezone.utc).astimezone().isoformat()

def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    derived = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310000)
    return base64.b64encode(salt).decode() + "$" + base64.b64encode(derived).decode()

def verify_password(password: str, encoded: str) -> bool:
    try:
        salt_b64, hash_b64 = encoded.split("$", 1)
        salt, expected = base64.b64decode(salt_b64), base64.b64decode(hash_b64)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310000)
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False

def make_token(user_id: str) -> str:
    expires = int((datetime.now(timezone.utc) + timedelta(hours=24)).timestamp())
    payload = base64.urlsafe_b64encode(json.dumps({"sub": user_id, "exp": expires}).encode()).decode().rstrip("=")
    signature = hmac.new(SECRET_KEY, payload.encode(), hashlib.sha256).digest()
    sig = base64.urlsafe_b64encode(signature).decode().rstrip("=")
    return payload + "." + sig

def get_current_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Faça login para continuar.")
    try:
        payload, signature = credentials.credentials.split(".", 1)
        expected = base64.urlsafe_b64encode(hmac.new(SECRET_KEY, payload.encode(), hashlib.sha256).digest()).decode().rstrip("=")
        if not hmac.compare_digest(signature, expected):
            raise ValueError("assinatura inválida")
        decoded = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
        if int(decoded["exp"]) < int(datetime.now(timezone.utc).timestamp()):
            raise ValueError("token expirado")
        user_id = decoded["sub"]
    except Exception:
        raise HTTPException(status_code=401, detail="Sessão inválida ou expirada. Entre novamente.")
    with connect() as conn:
        user = conn.execute("SELECT id,name,email FROM users WHERE id=?", (user_id,)).fetchone()
    if not user:
        raise HTTPException(status_code=401, detail="Usuário não encontrado.")
    return dict(user)

def academic_dict(row):
    return {"id": row["id"], "title": row["title"], "type": row["type"], "status": row["status"],
            "course": row["course"], "subject": row["subject"], "professor": row["professor"],
            "deadline": row["deadline"], "notes": row["notes"], "createdAt": row["created_at"]}

def document_dict(row):
    return {"id": row["id"], "name": row["name"], "category": row["category"], "academicType": row["academic_type"],
            "description": row["description"], "tags": json.loads(row["tags_json"]), "fileName": row["file_name"],
            "fileType": row["file_type"], "fileSize": row["file_size"], "createdAt": row["created_at"],
            "downloadUrl": f"/api/documents/{row['id']}/file"}

@app.get("/api/health")
def health():
    return {"status": "ok", "database": "SQLite"}

@app.post("/api/auth/register", status_code=201)
def register(payload: RegisterIn):
    user_id = str(uuid.uuid4())
    email = str(payload.email).lower()
    try:
        with connect() as conn:
            conn.execute("INSERT INTO users(id,name,email,password_hash,created_at) VALUES(?,?,?,?,?)",
                         (user_id, payload.name.strip(), email, hash_password(payload.password), now_iso()))
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="Já existe uma conta com esse e-mail.")
    return {"token": make_token(user_id), "user": {"id": user_id, "name": payload.name.strip(), "email": email}}

@app.post("/api/auth/login")
def login(payload: LoginIn):
    with connect() as conn:
        user = conn.execute("SELECT * FROM users WHERE email=? COLLATE NOCASE", (str(payload.email),)).fetchone()
    if not user or not verify_password(payload.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="E-mail ou senha incorretos.")
    return {"token": make_token(user["id"]), "user": {"id": user["id"], "name": user["name"], "email": user["email"]}}

@app.get("/api/auth/me")
def me(user=Depends(get_current_user)):
    return user

@app.get("/api/academic-records")
def list_academic_records(user=Depends(get_current_user)):
    with connect() as conn:
        rows = conn.execute("SELECT * FROM academic_records WHERE user_id=? ORDER BY created_at DESC", (user["id"],)).fetchall()
    return [academic_dict(row) for row in rows]

@app.post("/api/academic-records", status_code=201)
def create_academic_record(payload: AcademicRecordIn, user=Depends(get_current_user)):
    record_id, created_at, values = str(uuid.uuid4()), now_iso(), payload.model_dump()
    with connect() as conn:
        conn.execute("""INSERT INTO academic_records(id,user_id,title,type,status,course,subject,professor,deadline,notes,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
        (record_id,user["id"],values["title"].strip(),values["type"],values["status"],values["course"],values["subject"],values["professor"],values["deadline"],values["notes"],created_at))
        row = conn.execute("SELECT * FROM academic_records WHERE id=? AND user_id=?", (record_id,user["id"])).fetchone()
    return academic_dict(row)

@app.delete("/api/academic-records/{record_id}", status_code=204)
def delete_academic_record(record_id: str, user=Depends(get_current_user)):
    with connect() as conn:
        cursor = conn.execute("DELETE FROM academic_records WHERE id=? AND user_id=?", (record_id,user["id"]))
    if cursor.rowcount == 0:
        raise HTTPException(status_code=404, detail="Registro acadêmico não encontrado.")
    return None

@app.get("/api/documents")
def list_documents(user=Depends(get_current_user)):
    with connect() as conn:
        rows = conn.execute("SELECT * FROM documents WHERE user_id=? ORDER BY created_at DESC", (user["id"],)).fetchall()
    return [document_dict(row) for row in rows]

@app.post("/api/documents", status_code=201)
async def upload_document(name: str = Form(..., min_length=1, max_length=100), category: str = Form(...),
    academic_type: str = Form(""), description: str = Form(""), tags: str = Form(""), file: UploadFile = File(...),
    user=Depends(get_current_user)):
    if category not in {"saude","financas","judicial","lazer","faculdade"}:
        raise HTTPException(status_code=422, detail="Categoria inválida.")
    original_name = Path(file.filename or "arquivo").name
    document_id = str(uuid.uuid4())
    stored_name = f"{document_id}{Path(original_name).suffix[:20]}"
    destination = UPLOAD_DIR / stored_name
    size = 0
    try:
        with destination.open("wb") as output:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > 100 * 1024 * 1024:
                    output.close(); destination.unlink(missing_ok=True)
                    raise HTTPException(status_code=413, detail="O arquivo excede o limite de 100 MB.")
                output.write(chunk)
    finally:
        await file.close()
    created_at = now_iso()
    tags_list = [tag.strip() for tag in tags.split(",") if tag.strip()][:30]
    with connect() as conn:
        conn.execute("""INSERT INTO documents(id,user_id,name,category,academic_type,description,tags_json,file_name,stored_name,file_type,file_size,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
        (document_id,user["id"],name.strip(),category,academic_type,description,json.dumps(tags_list),original_name,stored_name,file.content_type or "application/octet-stream",size,created_at))
        row = conn.execute("SELECT * FROM documents WHERE id=? AND user_id=?", (document_id,user["id"])).fetchone()
    return document_dict(row)

@app.get("/api/documents/{document_id}/file")
def download_document(document_id: str, preview: bool = Query(default=False), user=Depends(get_current_user)):
    with connect() as conn:
        row = conn.execute("SELECT * FROM documents WHERE id=? AND user_id=?", (document_id,user["id"])).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Documento não encontrado.")
    path = UPLOAD_DIR / row["stored_name"]
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Arquivo não encontrado no armazenamento.")
    return FileResponse(path, media_type=row["file_type"], filename=row["file_name"], content_disposition_type="inline" if preview else "attachment")

@app.delete("/api/documents/{document_id}", status_code=204)
def delete_document(document_id: str, user=Depends(get_current_user)):
    with connect() as conn:
        row = conn.execute("SELECT stored_name FROM documents WHERE id=? AND user_id=?", (document_id,user["id"])).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Documento não encontrado.")
        conn.execute("DELETE FROM documents WHERE id=? AND user_id=?", (document_id,user["id"]))
    (UPLOAD_DIR / row["stored_name"]).unlink(missing_ok=True)
    return None
